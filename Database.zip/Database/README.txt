AI database Base

A terminal-based personal knowledge base built in Python using Rich, Transformers, and PyPDF2

- My first real AI project
- Add, edit, view, and delete personal entries
- Search through entries
- Summarize PDFs using AI (hugging face)
- All data saved locally in JSON
- Quite simple to use
- I did use chat gpt to make the code readable because it was very unreadable before
- Entries are stored at:
    ~/.local/share/database.json
