#!/usr/bin/env python3
import json
import os
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
from transformers import pipeline
from PyPDF2 import PdfReader

DB_PATH = os.path.expanduser("~/.local/share/database.json")
console = Console()

def print_title():
    ascii_art = """
██████╗░░█████╗░████████╗░█████╗░██████╗░░█████╗░░██████╗███████╗
██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝
██║░░██║███████║░░░██║░░░███████║██████╦╝███████║╚█████╗░█████╗░░
██║░░██║██╔══██║░░░██║░░░██╔══██║██╔══██╗██╔══██║░╚═══██╗██╔══╝░░
██████╔╝██║░░██║░░░██║░░░██║░░██║██████╦╝██║░░██║██████╔╝███████╗
╚═════╝░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝╚═════╝░╚═╝░░╚═╝╚═════╝░╚══════╝
"""
    purple = "bold magenta"
    for line in ascii_art.splitlines():
        console.print(line, style=purple, justify="center")
    console.print()

def load_db():
    if not os.path.exists(DB_PATH):
        return []
    try:
        with open(DB_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        return []

def save_db(entries):
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=2)

def add_entry(entries):
    console.print("[bold green]Add a new entry[/bold green]")
    title = Prompt.ask("[cyan]Enter title[/cyan]")
    content = Prompt.ask("[cyan]Enter content[/cyan]")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entries.append({"title": title, "content": content, "timestamp": timestamp})
    save_db(entries)
    console.print("[bold green]Entry added successfully![/bold green]\n")

def list_entries(entries):
    if not entries:
        console.print("[yellow]No entries found.[/yellow]\n")
        return
    table = Table(title="Entries", title_style="bold magenta")
    table.add_column("ID", justify="right", style="bright_black")
    table.add_column("Title", style="bright_cyan")
    table.add_column("Timestamp", style="bright_magenta")
    for i, entry in enumerate(entries, 1):
        table.add_row(str(i), entry["title"], entry["timestamp"])
    console.print(table)
    console.print()

def view_entry(entries):
    if not entries:
        console.print("[yellow]No entries to view.[/yellow]\n")
        return
    list_entries(entries)
    choice = Prompt.ask("[blue]Enter ID to view (or 'cancel')[/blue]").lower()
    if choice == "cancel":
        console.print("[yellow]View cancelled.[/yellow]\n")
        return
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(entries):
            entry = entries[idx]
            console.rule(f"[bright_cyan]{entry['title']}[/bright_cyan]")
            console.print(f"[magenta]Timestamp:[/magenta] {entry['timestamp']}\n")
            console.print(entry["content"])
            console.rule()
            console.print()
        else:
            console.print("[red]Invalid ID.[/red]\n")
    except ValueError:
        console.print("[red]Invalid input.[/red]\n")

def search_entries(entries):
    term = Prompt.ask("[magenta]Enter search term[/magenta]").lower()
    results = [e for e in entries if term in e["title"].lower() or term in e["content"].lower()]
    if not results:
        console.print(f"[yellow]No matching entries found for '{term}'.[/yellow]\n")
        return
    table = Table(title=f"Search results for '{term}'", title_style="bold magenta")
    table.add_column("ID", justify="right", style="bright_black")
    table.add_column("Title", style="bright_cyan")
    table.add_column("Timestamp", style="bright_magenta")
    for i, entry in enumerate(results, 1):
        table.add_row(str(i), entry["title"], entry["timestamp"])
    console.print(table)
    console.print()

    choice = Prompt.ask("[blue]Enter ID to view from results (or 'cancel')[/blue]").lower()
    if choice == "cancel":
        console.print("[yellow]View cancelled.[/yellow]\n")
        return
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(results):
            entry = results[idx]
            console.rule(f"[bright_cyan]{entry['title']}[/bright_cyan]")
            console.print(f"[magenta]Timestamp:[/magenta] {entry['timestamp']}\n")
            console.print(entry["content"])
            console.rule()
            console.print()
        else:
            console.print("[red]Invalid ID.[/red]\n")
    except ValueError:
        console.print("[red]Invalid input.[/red]\n")

def delete_entry(entries):
    list_entries(entries)
    if not entries:
        return
    choice = Prompt.ask("[red]Enter ID to delete (or 'cancel')[/red]").lower()
    if choice == "cancel":
        console.print("[yellow]Delete cancelled.[/yellow]\n")
        return
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(entries):
            removed = entries.pop(idx)
            save_db(entries)
            console.print(f"[bold red]Deleted entry:[/bold red] {removed['title']}\n")
        else:
            console.print("[red]Invalid ID.[/red]\n")
    except ValueError:
        console.print("[red]Invalid input.[/red]\n")

def edit_entry(entries):
    list_entries(entries)
    if not entries:
        return
    choice = Prompt.ask("[yellow]Enter ID to edit (or 'cancel')[/yellow]").lower()
    if choice == "cancel":
        console.print("[yellow]Edit cancelled.[/yellow]\n")
        return
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(entries):
            entry = entries[idx]
            console.print(f"Editing entry: [cyan]{entry['title']}[/cyan]")
            new_title = Prompt.ask("[cyan]New title[/cyan]", default=entry["title"])
            new_content = Prompt.ask("[cyan]New content[/cyan]", default=entry["content"])
            entry["title"] = new_title
            entry["content"] = new_content
            entry["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            save_db(entries)
            console.print("[bold green]Entry updated successfully![/bold green]\n")
        else:
            console.print("[red]Invalid ID.[/red]\n")
    except ValueError:
        console.print("[red]Invalid input.[/red]\n")

def summarize_pdf_and_save(entries):
    pdf_path = Prompt.ask("[cyan]Enter path to PDF to summarize[/cyan]")
    if not os.path.exists(pdf_path):
        console.print("[red]File not found![/red]")
        return

    console.print("[yellow]Extracting text from PDF...[/yellow]")
    reader = PdfReader(pdf_path)
    full_text = ""
    for page in reader.pages:
        text = page.extract_text()
        if text:
            full_text += text + "\n"

    if not full_text.strip():
        console.print("[red]No text found in PDF![/red]")
        return

    console.print("[yellow]Summarizing PDF content... (this may take a moment)[/yellow]")
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

    summary = summarizer(full_text, max_length=150, min_length=40, do_sample=False)[0]['summary_text']

    title = Prompt.ask("[cyan]Enter title for this summary entry[/cyan]")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    entries.append({"title": title, "content": summary, "timestamp": timestamp})
    save_db(entries)
    console.print("[bold green]Summary entry added successfully![/bold green]\n")

def main():
    entries = load_db()
    print_title()

    while True:
        console.print("[bold magenta]Options:[/bold magenta] [green]add[/green], [yellow]edit[/yellow], [cyan]search[/cyan], [bright_cyan]list[/bright_cyan], [blue]view[/blue], [red]delete[/red], [blue]summarize_pdf[/blue], [bright_red]quit[/bright_red]")
        choice = Prompt.ask("[bold white]Your choice[/bold white]").lower()
        console.print()

        if choice == "add":
            add_entry(entries)
        elif choice == "edit":
            edit_entry(entries)
        elif choice == "search":
            search_entries(entries)
        elif choice == "list":
            list_entries(entries)
        elif choice == "view":
            view_entry(entries)
        elif choice == "delete":
            delete_entry(entries)
        elif choice == "summarize_pdf":
            summarize_pdf_and_save(entries)
        elif choice == "quit":
            console.print("[bold magenta]Goodbye![/bold magenta]")
            break
        else:
            console.print("[bold red]Invalid option. Try again.[/bold red]\n")

if __name__ == "__main__":
    main()
